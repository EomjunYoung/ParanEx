#ifndef __KEY_H__
#define __KEY_H__

#define VISION_KEY "AIzaSyDl0trokyUz3QVyGwBEIi03PAWcBO1voCM"
#endif