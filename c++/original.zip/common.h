#ifndef __COMMON_H__
#define __COMMON_H__

#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <string.h>
#include <opencv2/opencv.hpp>

#define BUFF_SIZE 1024

using namespace std;
using namespace cv;

#endif